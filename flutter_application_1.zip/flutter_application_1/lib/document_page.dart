import 'package:flutter/material.dart';
class DocumentPage extends StatefulWidget {
  const DocumentPage({super.key});

  @override
  State<DocumentPage> createState() => _DocumentPageState();
}

class _DocumentPageState extends State<DocumentPage> {
  final List<Map<String, dynamic>> docs = [
    {"name": "Mou.pdf", "size": "23 MB", "type": "pdf"},
    {"name": "Tmr_meeting.pdf", "size": "50 MB", "type": "pdf"},
    {"name": "budgetsign.docx", "size": "50 MB", "type": "docx"},
  ];

  void _confirmDelete(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Do you want to delete ${docs[index]['name']}?"),
        actions: [
          TextButton(
            onPressed: () {
              setState(() => docs.removeAt(index));
              Navigator.pop(context);
            },
            child: const Text("Yes"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Document List"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        children: [
          ...docs.asMap().entries.map((e) {
            final index = e.key;
            final doc = e.value;
            return ListTile(
              leading: Icon(
                doc['type'] == 'pdf' ? Icons.picture_as_pdf : Icons.description,
                color: doc['type'] == 'pdf' ? Colors.red : Colors.blue,
              ),
              title: Text(doc['name']),
              subtitle: Text(doc['size']),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                      icon: const Icon(Icons.edit_outlined),
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Edit ${doc['name']}")),
                        );
                      }),
                  IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => _confirmDelete(index)),
                ],
              ),
            );
          }),
          ListTile(
            title: const Text("Add new files"),
            trailing: const Icon(Icons.add),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Upload feature here...")),
              );
            },
          )
        ],
      ),
    );
  }
}
